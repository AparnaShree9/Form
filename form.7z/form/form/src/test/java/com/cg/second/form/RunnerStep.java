package com.cg.second.form;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = {"pretty","json:TestResults/HtmlResults"},tags="@tag2")
public class RunnerStep {

}
