package com.cg.second.form;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefForm {
	
	private WebDriver driver;
	private FormPageFactory formfactory;

	
	@Given("^user is on form webpage$")
	public void user_is_on_form_webpage() throws Throwable {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\apshree\\Desktop\\chromedriver.exe");
    	  driver= new ChromeDriver();
    	 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    	 formfactory = new FormPageFactory(driver);
    	 driver.get("file:///D:/BDD/Basicform.html");
		
	}
	@When("^entered Wrong name$")
	public void entered_Wrong_name() throws Throwable {
		formfactory.setName("king123");
		 Thread.sleep(1000);
		 formfactory.setCity("Chennai");
		  Thread.sleep(1000);
		  formfactory.setPassword("123@abc");
		  Thread.sleep(1000);
		  formfactory.setGender("male");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  formfactory.setCountry(1);
		  Thread.sleep(1000);
		  
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  Thread.sleep(1000);
		  formfactory.setContact("9632587412");
		  Thread.sleep(1000);
	}
	@Then("^error message is printed$")
	public void error_message_is_printed() throws Throwable {
		String alert = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alert);
		Thread.sleep(2000);
		driver.close();
	}
	@When("^entered all data with name field left empty$")
	public void entered_all_data_with_name_field_left_empty() throws Throwable {
		formfactory.setName("");
		  Thread.sleep(1000);
		  formfactory.setCity("Bhopal");
		  Thread.sleep(1000);
		  formfactory.setPassword("abcdef@abc");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  Thread.sleep(1000);
		  formfactory.setContact("7894561236");
		  Thread.sleep(1000);
	}

	@When("^entered all data with password field left empty$")
	public void entered_all_data_with_password_field_left_empty() throws Throwable {
		formfactory.setName("Shree");
		  Thread.sleep(1000);
		  formfactory.setCity("Bhopal");
		  Thread.sleep(1000);
		  formfactory.setPassword("");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  Thread.sleep(1000);
		  formfactory.setContact("7894561236");
		  Thread.sleep(1000);
	}
	@When("^entered wrong password$")
	public void entered_wrong_password() throws Throwable {
		formfactory.setName("Aparna Shree");
		  Thread.sleep(1000);
		  formfactory.setCity("Bhopal");
		  Thread.sleep(1000);
		  formfactory.setPassword("asd");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  Thread.sleep(1000);
		  formfactory.setContact("9632587412");
		  Thread.sleep(1000);
	}

	@When("^entered all data with  email left empty$")
	public void entered_all_data_with_email_left_empty() throws Throwable {
		 formfactory.setName("Shree");
		  Thread.sleep(1000);
		  formfactory.setCity("Bhopal");
		  Thread.sleep(1000);
		  formfactory.setPassword("abcdef@abc");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("");
		  Thread.sleep(1000);
		  formfactory.setContact("7894561236");
		  Thread.sleep(1000);
	}

	@When("^entered all data with contact left empty$")
	public void entered_all_data_with_contact_left_empty() throws Throwable {
		 formfactory.setName("Shree");
		  Thread.sleep(1000);
		  formfactory.setCity("Bhopal");
		  Thread.sleep(1000);
		  formfactory.setPassword("abcdef@abc");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  Thread.sleep(1000);
		  formfactory.setContact("");
		  Thread.sleep(1000);
	}



	@When("^entered wrong number$")
	public void entered_wrong_number() throws Throwable {
		formfactory.setName("Shree");
		  Thread.sleep(1000);
		  formfactory.setCity("Bhopal");
		  Thread.sleep(1000);
		  formfactory.setPassword("abcdef@abc");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  formfactory.setNumber("256");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  Thread.sleep(1000);
		  formfactory.setContact("7894561236");
		  Thread.sleep(1000);
	}

	

	@When("^left number empty$")
	public void left_number_empty() throws Throwable {
		formfactory.setName("Shree");
		  Thread.sleep(1000);
		  formfactory.setCity("Bhopal");
		  Thread.sleep(1000);
		  formfactory.setPassword("abcdef@abc");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  formfactory.setNumber("");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  Thread.sleep(1000);
		  formfactory.setContact("7894561236");
		  Thread.sleep(1000);
	}

	
	@When("^entered wrong email$")
	public void entered_wrong_email() throws Throwable {
		 formfactory.setName("Shree");
		  Thread.sleep(1000);
		  formfactory.setCity("Bhopal");
		  Thread.sleep(1000);
		  formfactory.setPassword("abcdef@abc");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("abcd");
		  Thread.sleep(1000);
		  formfactory.setContact("9632587478");
		  Thread.sleep(1000);
	}

	@When("^entered wrong contact$")
	public void entered_wrong_contact() throws Throwable {
		 formfactory.setName("Shree");
		  Thread.sleep(1000);
		  formfactory.setCity("Bhopal");
		  Thread.sleep(1000);
		  formfactory.setPassword("abcdef@abc");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  Thread.sleep(1000);
		  formfactory.setContact("1236");
		  Thread.sleep(1000);
	
	}

	@When("^entered all correct details$")
	public void entered_all_correct_details() throws Throwable {
		formfactory.setName("Aparna");
		  Thread.sleep(1000);
		  formfactory.setCity("Chennai");
		  Thread.sleep(1000);
		  formfactory.setPassword("123@abc");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  //formfactory.adminViaDropDown(0);
		  Thread.sleep(1000);
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  
		  Thread.sleep(1000);
		  
		  formfactory.setContact("9632587412");
		  Thread.sleep(1000);
	}
	@When("^gender not selected$")
	public void gender_not_selected() throws Throwable {
		formfactory.setName("Aparna");
		  Thread.sleep(1000);
		  formfactory.setCity("Chennai");
		  Thread.sleep(1000);
		  formfactory.setPassword("123@abc");
		  Thread.sleep(1000);
		
		  List<Integer>lang = new ArrayList<Integer>();
		  lang.add(1);
		  lang.add(2);
		  formfactory.setLanguage(lang);
		  Thread.sleep(1000);
		  
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  Thread.sleep(1000);
		  formfactory.setContact("9632587412");
		  Thread.sleep(1000);
	}

	@When("^language not selected$")
	public void language_not_selected() throws Throwable {
		formfactory.setName("Aparna");
		  Thread.sleep(1000);
		  formfactory.setCity("Chennai");
		  Thread.sleep(1000);
		  formfactory.setPassword("123@abc");
		  Thread.sleep(1000);
		  formfactory.setGender("female");
		  Thread.sleep(1000);
		  
		  
		  formfactory.setNumber("20");
		  Thread.sleep(1000);
		  formfactory.setEmail("aparna@gmail.com");
		  Thread.sleep(1000);
		  formfactory.setContact("9632587412");
		  Thread.sleep(1000);
	}
	@When("^all fields empty$")
	public void all_fields_empty() throws Throwable {
		 formfactory.setName("");
		  Thread.sleep(1000);
		  formfactory.setCity("");
		  Thread.sleep(1000);
		  formfactory.setPassword("");
		  Thread.sleep(1000);
		  formfactory.setNumber("");
		  Thread.sleep(1000);
		  formfactory.setEmail("");
		  Thread.sleep(1000);
		  formfactory.setContact("");
		  Thread.sleep(1000);
	}

	@Then("^success web page opened$")
	public void success_web_page_opened() throws Throwable {
	   driver.get("file:///D:/BDD/success.html");
	   Thread.sleep(2000);
	   driver.close();
	}

	@When("^click submit$")
	public void click_submit() throws Throwable {
	  formfactory.setStore();
	}

	
}