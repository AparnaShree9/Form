package com.cg.second.form;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
public class FormPageFactory {
	WebDriver wd;
	WebElement we;
	@FindBy(how= How.NAME,using= "userName")
	@CacheLookup
	WebElement name;
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	@FindBy(name="password")
	@CacheLookup
	WebElement password;
	@FindBy(how= How.XPATH, using="/html/body/center/form/input[11]")
	@CacheLookup
	WebElement number;
	@FindBy(how= How.XPATH, using="/html/body/center/form/input[12]")
	@CacheLookup
	WebElement email;
	@FindBy(name="mobile")
	@CacheLookup
	WebElement contact;
	@FindBy(how=How.CSS, using="body > center >  form > input[type=\"reset\"]:nth-child(45)")
	@CacheLookup
	WebElement clear;
	@FindBy(xpath="/html/body/center/form/input[15]")
	@CacheLookup
	WebElement store;
	@FindBy(name="gender")
	@CacheLookup
	List<WebElement> gender;
	@FindBy(name="lang")
	@CacheLookup
	List<WebElement> language;
	
	@FindBy(name="country")
	@CacheLookup
	List<WebElement> country;
	
	
	
	public FormPageFactory() {
		super();
	}
	
	public FormPageFactory(WebDriver driver) {
		this.wd=driver;
		PageFactory.initElements(wd,this);
	}
	
	
	
	
	public List<WebElement> getCountry() {
		return country;
	}

	public void setCountry(Integer country) {
		Select drop = new Select(wd.findElement(By.className("country")));
		int a=0;
		if(a==1) {
			drop.selectByIndex(0);
		}if(a==1) {
			drop.selectByIndex(1);
		}if(a==2) {
			drop.selectByIndex(2);
		}if(a==3) {
			drop.selectByIndex(3);
		}if(a==4) {
			drop.selectByIndex(4);
		}
		else {
			
		}
		
		
	
	
	
	}

	public  void adminViaDropDown(int index) {
	     we = wd.findElement(By.className("country"));
	      Select drop = new Select(we);
	      drop.selectByIndex(index);  
	}
	
	
	public List<WebElement> getGender() {
		return gender;
	}

	public void setGender(String gender) {
		if(gender.equalsIgnoreCase("male")) {
			this.gender.get(0).click();
		}
		else if(gender.equalsIgnoreCase("female")){
			this.gender.get(0).click();
		
		}else {}
	}

	public List<WebElement> getLanguage() {
		return language;
	}

	public void setLanguage(List<Integer> language) {
		Iterator<Integer> it = language.iterator();
		while(it.hasNext()) {
			int a= it.next();
			if(a==1) 
				this.language.get(0).click();
			if(a==2)
				this.language.get(1).click();
		    if(a==3) {
			this.language.get(2).click();
		    }else {}
		   	}
	}

	

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number.sendKeys(number);;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}

	public WebElement getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact.sendKeys(contact);;
	}
	
	
	public WebElement getClear() {
		return clear;
	}

	
	public void setClear() {
		clear.click();
	}

	public WebElement getStore() {
		return store;
	}

	public void setStore() {
		store.click();
	}
	
}
